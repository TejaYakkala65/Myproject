import React, { useEffect } from "react";
import { useSelector } from "react-redux";
import homeLogo from '../src/images/home.svg';
import isEmpty from "./Utility";
import { useNavigate } from "react-router";

export default () => {
    const userInfo = useSelector(state => state?.userDetails?.userInfo);
    const navigate = useNavigate()
    useEffect(()=>{
        if(isEmpty(userInfo)){
            console.log(userInfo)
            window.open("http://localhost:3000/unAuthorized","_self");
        }
    },[])

    return (
        <React.Fragment>
            {userInfo!=null && <section class="min-vh-100 align-items-center justify-content-center overflow-hidden" style={{"background-color" : "#9de2ff"}}>
            <img style={{"background-color" : "#9de2ff"}} src={homeLogo} alt="Go Home" onClick={()=>{navigate("/home")}}/>
                <div class="row">
                    <div className="col-3"></div>
                    <div class="col-6">
                        <div class="card rounded-4">
                            <div class="card-body p-4">
                                <div className="row">
                                    <div className="col-4">
                                        <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-profiles/avatar-1.webp"
                                            alt="Generic placeholder image" class="w-100" />
                                    </div>
                                    <div className="col-8">
                                        <h5 class="mb-1">{userInfo?.userName}</h5>
                                        <div style={{"background-color": "#efefef"}}>
                                            <div className="row">
                                                <div className="col">
                                                    <p class="small text-muted mb-1">Phone Number</p>
                                                    <p class="mb-0">{userInfo?.mobile}</p>
                                                </div>
                                                <div className="col">
                                                    <p class="small text-muted mb-1">Email Id</p>
                                                    <p class="mb-0">{userInfo?.email}</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="row pt-5">
                                            <div className="col text-center">
                                                <button className="btn btn-outline-danger w-75">click me</button>
                                            </div>
                                            <div className="col text-center">
                                                <button className="btn btn-outline-success w-75">click me</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="col-3"></div>
                </div>
            </section>}
        </React.Fragment>
    )
}