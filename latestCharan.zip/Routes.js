import { Route, Routes } from 'react-router';
import { BrowserRouter } from 'react-router-dom';
import DisplayingErrorMessagesExample from './DisplayingErrorMessagesExample';
import Home from './Home';
import ViewProfile from './ViewProfile';
import UnAuthorized from './UnAuthorized';
import SignUp from './SignUp';
import { createBrowserHistory } from 'history';


export default () => {
    const history = createBrowserHistory();
    return (
        <BrowserRouter>
            <Routes>
                <Route path="/signUp" element={<SignUp />} />
                <Route path="/" element={<DisplayingErrorMessagesExample />} />
                <Route path="/home" element={<Home history={history} />} />
                <Route path="/viewProfile" element={<ViewProfile />} />
                <Route path="/unAuthorized" element={<UnAuthorized />} />
            </Routes>
        </BrowserRouter>)
}