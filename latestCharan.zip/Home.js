import React, { useEffect, useState } from "react"
import HeaderComponent from "./HeaderComponent"
import BodyComponent from "./BodyComponent"
import { useSelector } from "react-redux";
import isEmpty from "./Utility";
import { useNavigate } from "react-router";

export default (props)=>{
    const userInfo = useSelector(state => state?.userDetails?.userInfo);
    const [productName,setProductName] = useState(null);
    const [productId,setProductId] = useState(null);
    
    useEffect(()=>{
        if(isEmpty(userInfo)){
            console.log(userInfo)
            useNavigate("/unAuthorized");
        }
    },[])

    return(
        <React.Fragment>
            <HeaderComponent callBack={(name)=>{setProductName(name)}} removeFromSearch={productId} {...props}/>
            <BodyComponent showProduct={productName} removeFromSearch={(id)=>{setProductId(id)}} {...props}/>
        </React.Fragment>
    )
}