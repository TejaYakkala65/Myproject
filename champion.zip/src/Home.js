import React, { useEffect } from "react"
import HeaderComponent from "./HeaderComponent"
import BodyComponent from "./BodyComponent"
import { useSelector } from "react-redux";
import isEmpty from "./Utility";

export default ()=>{
    const userInfo = useSelector(state => state?.userDetails?.userInfo);
    useEffect(()=>{
        if(isEmpty(userInfo)){
            console.log(userInfo)
            window.open("http://localhost:3000/unAuthorized","_self");
        }
    },[])
    return(
        <React.Fragment>
            <HeaderComponent/>
            <BodyComponent/>
        </React.Fragment>
    )
}