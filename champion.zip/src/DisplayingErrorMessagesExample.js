import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Col, Button, Row, Container, Card, Form } from 'react-bootstrap';
import { addUserInfo, removeUserInfo } from './redux/action/UserActions';
import isEmpty from './Utility';


export default () => {
    const userInfo = useSelector(state => state?.userDetails?.userInfo);
    const dispatch = useDispatch();
    const [userName, setUserName] = useState(null);
    const [password, setPassword] = useState(null);
    /* const [userInofs, setUserInfos] = useState(null); */
    
    const getData = async () => {
        var requestOptions = {
            method: "GET",
            redirect: "follow",
        };
        return fetch("http://localhost:3001/users", requestOptions)
            .then((response) => response.json())
            .then((result) => { return result })
            .catch((error) => console.log("error", error));
    };

    const validateAndRedirectToHome = async () => {
        if(isEmpty(userName) || isEmpty(password)){
            alert("please provide username and password to log in");
            return;
        }
        const userInfos = await getData();
        dispatch(removeUserInfo());
        userInfos.map((eachUser) => {
            if (eachUser.userName.toLowerCase() == userName.toLowerCase() && eachUser.password == password) {
                dispatch(addUserInfo(eachUser));
                window.open("/home","_self");
                return
            }
        })
        alert("please check user name and password")
        return;
    }
    return (
        <Container>
            <Row className="vh-100 d-flex justify-content-center align-items-center">
                <Col md={8} lg={6} xs={12}>
                    <Card className="px-4">
                        <Card.Body>
                            <div className="mb-3 mt-md-4">
                                <h2 className="fw-bold mb-2 text-center text-uppercase ">
                                    Log In
                                </h2>
                                <div className="mb-3">
                                    <Form>
                                        <Form.Group className="mb-3" controlId="Name">
                                            <Form.Label className="text-center">Name</Form.Label>
                                            <Form.Control type="text" placeholder="Enter Name" onChange={(e) => { setUserName(e.target.value) }} />
                                        </Form.Group>

                                        <Form.Group
                                            className="mb-3"
                                            controlId="formBasicCheckbox"
                                        ></Form.Group>
                                        <Form.Group
                                            className="mb-3"
                                            controlId="formBasicPassword"
                                        >
                                            <Form.Label>Password</Form.Label>
                                            <Form.Control type="password" placeholder="Password" onChange={(e) => { setPassword(e.target.value) }} />
                                        </Form.Group>
                                        <div className="d-grid">
                                            <Button variant="primary" type="submit" onClick={() => { validateAndRedirectToHome() }}>
                                                Log In
                                            </Button>
                                        </div>
                                    </Form>
                                </div>
                            </div>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>
        </Container>
    )
};