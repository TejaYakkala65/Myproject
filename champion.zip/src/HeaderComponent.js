import React, { useEffect, useState } from "react"
import homeLogo from '../src/images/home.svg'
import profileLogo from '../src/images/profile.svg'
/* import { FontAwesomeIcon } from '@fortawesome';
import { faHome } from '@fortawesome/free-solid-svg-icons'; */

export default () =>{
    const [products,setProducts] = useState(null);
    useEffect(()=>{
        getData();
    },[])
    const getData = async() => {
        var requestOptions = {
          method: "GET",
          redirect: "follow",
        };
        fetch("http://localhost:3001/products", requestOptions)
          .then((response) => response.json())
          .then((result) => setProducts(result))
          .catch((error) => console.log("error", error));
      };
    const handleOnChange=(value)=>{
        let listOfSimilarNameProducts = products.filter((eachProduct)=>{
            if(eachProduct.name.toLowerCase().contains(value))
                return eachProduct;
        })

    }
    const redirectToViewProfile=()=>{
        window.open("viewProfile","_self");
    }
    return (
        <React.Fragment>
            {/* <FontAwesomeIcon icon={faHome} /> */}
            <div class="container-fluid col-auto">
                <div class="row">
                    <img className="col-auto" src={homeLogo} />
                    <div class="input-group">
                        <div class="form-outline">
                            <input type="search" id="form1" class="form-control" onChange={e => { handleOnChange(e.target.value) }} />
                            <label class="form-label" for="form1">Search</label>
                        </div>
                        <button type="button" class="btn btn-primary">
                            search
                        </button>
                    </div>
                    <img className="col-auto" src={profileLogo} height={'24px'} width={'24px'} onClick={()=>{redirectToViewProfile()}}/>
                </div>
            </div>
        </React.Fragment>
    )
}