import React, { useEffect, useState } from "react"
import ProductCard from "./ProductCard";

export default () =>{
    const [products,setProducts] = useState(null);
    useEffect(()=>{
        getData();
    },[])
    const getData = async() => {
        var requestOptions = {
          method: "GET",
          redirect: "follow",
        };
        fetch("http://localhost:3001/products", requestOptions)
          .then((response) => response.json())
          .then((result) => setProducts(result))
          .catch((error) => console.log("error", error));
      };
    return (
        <React.Fragment>
            {products && products.map((eachProduct=>{
                return  <div className="container mt-5">
                <div className="row">
                <ProductCard productInfo={eachProduct}/>
                </div>
                </div>
            }))}
        </React.Fragment>
    )
}