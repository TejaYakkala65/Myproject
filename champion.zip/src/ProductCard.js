import React from "react";


const ProductCard = (props) => {
    const { productInfo } = props;
    return (
        <React.Fragment>
            <div className="card">
                <img src={productInfo?.image} className="card-img-top" alt={productInfo?.name} />
                <div className="card-body">
                    <h5 className="card-title">{productInfo?.name}</h5>
                    <p className="card-text">{productInfo?.description}</p>
                    <p className="card-text">Price: ${productInfo?.price}</p>
                </div>
            </div>
        </React.Fragment>
    )
}
export default ProductCard;